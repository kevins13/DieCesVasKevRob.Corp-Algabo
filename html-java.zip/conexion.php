<?php
$host = "localhost";
$dbuser= "root";
$dbpwd= "";
$db = "archivo";

$conexion = mysqli_connect($host, $dbuser, $dbpwd);
if(!$conexion)
echo("error conectando a la base de datos");
else
$select=mysqli_select_db($conexion,$db);
?>