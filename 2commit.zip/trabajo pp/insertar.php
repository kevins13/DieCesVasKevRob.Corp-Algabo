<?php 

	header("Access-Control-Allow-Origin: *")

	$conexion=mysqli_connect('localhost','root','','trabajoFinal');

	$nombre=$_POST['nombre'];
	$apellido=$_POST['apellido'];
	$usuario=$_POST['usuario'];

	$sql="INSERT into producto (nombre,cantidad,provedor)
			values ('$nombre','$usuario','$apellido')";
	echo mysqli_query($conexion,$sql);
 ?>