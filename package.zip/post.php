<?php

$usuario = $_POST['nombre'];
$proovedor = $_POST['Pro'];
$cantidad = $_POST['canti'];

if($usuario ==="" || $proovedor ==="")
{
    echo json_encode("llena todos los campos");
}
else{
    echo json_encode("correcto <br> usuario" .$usuario.' <br>provedor:' .$proovedor );
}