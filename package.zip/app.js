var mysql = require("mysql");

var conexion = mysql.createConnection({
    host:"localhost",
    database:"trabajoFinal",
    user:"root",
    password:""
});
conexion.connect(function(Error){
    if(Error)
    {
        throw Error;
    }
    else
    {
        console.log("conexion exitosa");
    }
});

var querry = conexion.query('select * from producto', function(error,resultado){
    if(error)
    {
        throw error;
    }
    else
    {
        console.log(resultado);
    }
});
